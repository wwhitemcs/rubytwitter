# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TwitterExample::Application.config.secret_key_base = '5b2afe2c67ebef79dbeeb5325daf6787b39402e905d4e3d752e7d0e148423b295ef502c1f80297c1f229e17b198369e19e930f39f22bf7da025a2985b03512dd'
